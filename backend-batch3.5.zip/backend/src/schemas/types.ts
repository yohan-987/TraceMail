// Central type definitions — the single source of truth every batch/module
// imports from. Extend these in place as later batches add real analysis
// logic; never duplicate shape definitions in individual route files.
//
// ARCHITECTURE NOTE (Batch 0):
// emailId is the PRIMARY investigation identity. caseId is optional
// grouping metadata only. There is no backend "activeCase" or
// "activeEmail" concept — every email is independently retrievable and
// analyzable by emailId alone. Do not add code paths that require a
// caseId to exist before an email can be scanned or fetched.

export type AuthResult =
  | "pass"
  | "fail"
  | "softfail"
  | "neutral"
  | "none"
  | "temperror"
  | "permerror";

export type EvidenceStatus =
  | "VERIFIED"
  | "SUSPICIOUS"
  | "MALICIOUS"
  | "INCONCLUSIVE"
  | "UNAVAILABLE";

export type RiskLevel = "low" | "moderate" | "high" | "critical";

export interface EmailAddress {
  displayName: string | null;
  email: string | null;
  localPart: string | null;
  domain: string | null;
}

export interface AttachmentInfo {
  filename: string;
  mimeType: string;
  sizeBytes: number;
  sha256: string;
}

export interface BodyContent {
  text: string | null;
  html: string | null; // untrusted — never rendered without sanitization
}

// --- Per-emailId analysis objects -----------------------------------
// Each carries its own emailId so these can be stored/fetched/tested
// independently of the parent EmailRecord if needed later.

export interface ParsedEmail {
  emailId: string;
  subject: string | null;
  from: EmailAddress[];
  to: EmailAddress[];
  cc: EmailAddress[];
  bcc: EmailAddress[];
  replyTo: EmailAddress[];
  returnPath: EmailAddress[];
  date: string | null;
  messageId: string | null;
  headers: {
    normalized: Record<string, string | string[]>;
    raw: { name: string; value: string }[];
  };
  body: BodyContent;
  attachments: AttachmentInfo[];
}

export type IpClassification = "PUBLIC" | "PRIVATE" | "LOOPBACK" | "LINK_LOCAL" | "INVALID";

// The five scoring buckets used everywhere risk evidence is produced —
// header forensics (Batch 2), IOC/URL/domain/content analysis (Batch 3),
// and infrastructure enrichment (Batch 4) all tag their evidence with one
// of these so the risk engine can group and combine them per category.
export type RiskCategory = "technical" | "identity" | "urlDomain" | "content" | "infrastructure";

// Where a piece of evidence came from — lets the UI (and future
// reviewers) distinguish "we directly observed this fact" from "a
// model inferred this." Batch 3's evidence is deterministic rule
// output, so it's tagged DETERMINISTIC_ANALYSIS; the other values are
// reserved for Batch 4+ (GeoIP/threat-intel -> EXTERNAL_INTELLIGENCE,
// a future classifier -> ML_ASSESSMENT, an LLM's semantic read ->
// AI_INTERPRETATION, a derived-but-not-directly-observed conclusion ->
// INFERRED). Nothing in Batch 3.5 produces those yet.
export type EvidenceProvenance =
  | "OBSERVED"
  | "DETERMINISTIC_ANALYSIS"
  | "EXTERNAL_INTELLIGENCE"
  | "ML_ASSESSMENT"
  | "AI_INTERPRETATION"
  | "INFERRED";

export interface HeaderAnomaly {
  type: string; // e.g. "reply_to_mismatch", "spf_fail"
  severity: "low" | "medium" | "high";
  message: string;
  evidence: Record<string, unknown>;
  weight: number; // risk contribution, NOT a probability — the risk engine consumes this
  category: RiskCategory;
  provenance: EvidenceProvenance;
}

// HeaderAnomaly's shape is deliberately general-purpose (not header-
// specific) — Batch 3's URL/domain/content analyzers reuse the exact
// same shape rather than introducing a parallel evidence type. This
// alias is just a more accurate name for code written after Batch 2.
export type RiskEvidenceItem = HeaderAnomaly;

export interface ReceivedHop {
  hop: number; // 1-based, in the order the header appears in the raw file
  fromHostname: string | null;
  fromIp: string | null;
  fromIpClassification: IpClassification | null;
  byHostname: string | null;
  timestampRaw: string | null;
  timestampIso: string | null;
  rawHeader: string;
}

// Batch 2 fills in real values; Batch 0 only established the shape.
export interface HeaderAnalysis {
  emailId: string;
  anomalies: HeaderAnomaly[];
  receivedChain: ReceivedHop[];
  status: EvidenceStatus;
}

export interface AuthenticationAnalysis {
  emailId: string;
  spf: { result: AuthResult | "unknown"; raw: string | null };
  dkim: { result: AuthResult | "unknown"; raw: string | null };
  dmarc: { result: AuthResult | "unknown"; policy: string | null; raw: string | null };
}

export interface IOCSet {
  emailId: string;
  ips: string[];
  domains: string[];
  urls: string[];
  hashes: string[];
  emails: string[];
}

export interface URLAnalysis {
  emailId: string;
  urls: {
    url: string;
    hostname: string;
    domain: string;
    isHttps: boolean;
    urlLength: number;
    subdomainLength: number;
    pathLength: number;
    queryLength: number;
    hasIpHost: boolean;
    hasAtSymbol: boolean;
    hasEncodedCharacters: boolean;
    hasMultipleSubdomains: boolean;
    isShortened: boolean;
    riskNotes: string[];
  }[];
}

export interface DomainAnalysis {
  emailId: string;
  domains: {
    domain: string;
    tld: string | null;
    subdomain: string | null;
    hostnameLength: number;
    hyphenCount: number;
    digitCount: number;
    isPunycode: boolean;
    lookalikeOf: string | null;
    similarityScore: number | null;
  }[];
}

// Whether a category's evidence could even be evaluated — distinct from
// the SCORE itself. A category with no applicable signals (e.g. no URLs
// in this email) or no evidence source yet (e.g. GeoIP not implemented
// until Batch 4) must never be silently treated as "0 = safe" — that's
// exactly the confusion this type prevents.
export type EvidenceAvailability = "AVAILABLE" | "NOT_APPLICABLE" | "UNAVAILABLE" | "ERROR";

export interface CategoryResult {
  score: number | null; // null whenever status !== "AVAILABLE"
  status: EvidenceAvailability;
  evidence: RiskEvidenceItem[];
}

export interface RiskAssessment {
  emailId: string;
  categoryScores: {
    technical: CategoryResult;
    identity: CategoryResult;
    urlDomain: CategoryResult;
    content: CategoryResult;
    infrastructure: CategoryResult;
  } | null;
  score: number | null; // null only when EVERY category is unavailable — never coerced to 0
  level: RiskLevel | null;
  classification: string | null;
  confidence: number | null;
  // Fraction (0-1) of the five categories that were AVAILABLE when this
  // assessment was computed. Lets the UI show "this score reflects 3 of
  // 5 categories" rather than implying full-coverage confidence.
  evidenceCoverage: number | null;
}

// --- Placeholders for future batches — no implementation yet ---------
// Deliberately unpopulated: routes never construct these with fake
// data. They exist only so EmailRecord has a documented slot for
// Batch 4+ to fill in without another type-shape migration.

export interface MLAssessment {
  emailId: string;
  status: EvidenceAvailability;
}

export interface IntelligenceAssessment {
  emailId: string;
  status: EvidenceAvailability;
}

export interface AIAssessment {
  emailId: string;
  status: "available" | "unavailable";
  phishingIntent: number | null;
  credentialHarvesting: number | null;
  financialFraud: number | null;
  impersonation: number | null;
  socialEngineering: number | null;
  malwareDelivery: number | null;
  summary: string | null;
}

export interface InfrastructureAssessment {
  emailId: string;
  candidateIp: string | null;
  country: string | null;
  region: string | null;
  city: string | null;
  isp: string | null;
  asn: string | null;
  confidence: number | null;
  status: EvidenceStatus;
}

export interface ForensicReport {
  emailId: string;
  generatedAt: string;
  htmlAvailable: boolean;
}

// --- Top-level record -------------------------------------------------

export interface EvidenceMeta {
  filename: string;
  sha256: string;
  fileSizeBytes: number;
  createdAt: string; // ISO timestamp
  storagePath: string; // relative path under data/emails/<emailId>/
}

export interface EmailRecord {
  emailId: string;
  caseId: string | null;
  evidence: EvidenceMeta;
  parsedEmail: ParsedEmail | null;
  headerAnalysis: HeaderAnalysis | null;
  authentication: AuthenticationAnalysis | null;
  iocs: IOCSet | null;
  urlAnalysis: URLAnalysis | null;
  domainAnalysis: DomainAnalysis | null;
  risk: RiskAssessment | null;
  aiAssessment: AIAssessment | null;
  infrastructure: InfrastructureAssessment | null;
  report: ForensicReport | null;
  // Every RiskEvidenceItem that contributed to `risk` — header anomalies
  // plus URL/domain/content evidence — in one flat list. This is the
  // single source the "Why flagged?" UI panel renders directly.
  explanations: RiskEvidenceItem[];
  warnings: string[];
  // Placeholders for future batches only — optional, never constructed
  // with fake values. Omitted entirely (not even `null`) until a real
  // implementation exists, so their absence in the JSON honestly means
  // "not yet built" rather than "checked, unavailable".
  mlAssessment?: MLAssessment | null;
  intelligenceAssessment?: IntelligenceAssessment | null;
}

// Lightweight shape for GET /emails table listing — avoids shipping
// full parsed bodies/headers when only a table row is needed.
export interface EmailSummary {
  emailId: string;
  caseId: string | null;
  filename: string;
  subject: string | null;
  fromDomain: string | null;
  createdAt: string;
  riskScore: number | null;
  riskLevel: RiskLevel | null;
}

export interface ScanAcceptedResponse {
  emailId: string;
  caseId: string | null;
  filename: string;
  sha256: string;
  fileSize: number;
  status: "accepted";
  warnings: string[];
}

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
  };
}
