import { Router, Request, Response, NextFunction } from "express";
import { uploadEml } from "../utils/upload";
import { sha256 } from "../utils/hash";
import { generateEmailId } from "../utils/ids";
import { assertSafeFilename } from "../utils/filename";
import { Errors } from "../utils/apiError";
import { parseEmlBuffer } from "../analyzers/emailParser";
import { analyzeHeaders } from "../analyzers/headerForensics";
import { extractIOCs } from "../analyzers/iocExtractor";
import { analyzeUrls } from "../analyzers/urlAnalyzer";
import { analyzeDomains } from "../analyzers/domainAnalyzer";
import { analyzeContent } from "../analyzers/contentHeuristics";
import { computeRisk } from "../analyzers/riskEngine";
import {
  saveOriginalEml,
  saveEmailRecord,
  getEmailRecord,
  listEmailSummaries,
} from "../services/emailStore";
import type { EmailRecord, ScanAcceptedResponse } from "../schemas/types";

export const emailsRouter = Router();

// POST /api/v1/emails/scan
// Batch 1: validates upload, preserves the original .eml untouched,
// hashes evidence, parses it, and persists the full EmailRecord.
// Batch 2: header/authentication forensics now run here too.
// Batch 3: IOC extraction, URL/domain analysis, content heuristics, and
// the deterministic risk engine now run here too.
// Later batches (4) fill in aiAssessment/infrastructure enrichment on
// this same record — this route does not grow new analysis logic
// itself once those land.
emailsRouter.post(
  "/emails/scan",
  uploadEml.single("file"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const file = req.file;
      if (!file) throw Errors.missingFile();
      if (file.buffer.length === 0) throw Errors.emptyFile();

      assertSafeFilename(file.originalname);

      // Optional caseId for grouping — never required.
      const caseId =
        typeof req.body?.caseId === "string" && req.body.caseId.trim() !== ""
          ? req.body.caseId.trim()
          : null;

      // Hash the exact uploaded bytes BEFORE anything else touches them.
      const evidenceHash = sha256(file.buffer);
      const emailId = generateEmailId();

      // Preserve the original evidence untouched on disk.
      const storagePath = await saveOriginalEml(emailId, file.buffer);

      // Parse — never throws; malformed input degrades to warnings on
      // an otherwise-empty ParsedEmail rather than aborting the scan.
      const { parsed, warnings } = await parseEmlBuffer(emailId, file.buffer);

      // Batch 2: header/authentication forensics run on the parsed
      // structure — no re-parsing of the raw email needed.
      const { headerAnalysis, authentication } = analyzeHeaders(parsed);

      // Batch 3: IOCs reuse headerAnalysis's already-parsed Received
      // chain IPs rather than re-deriving them.
      const iocs = extractIOCs(parsed, headerAnalysis);
      const { urlAnalysis, evidence: urlEvidence } = analyzeUrls(emailId, iocs.urls);
      const { domainAnalysis, evidence: domainEvidence } = analyzeDomains(emailId, iocs.domains);
      const { evidence: contentEvidence } = analyzeContent(parsed);

      // Every RiskEvidenceItem across all analyzers feeds the risk
      // engine, which combines them per-category with a non-additive
      // aggregation (see riskEngine.ts) — never a blind sum, so
      // correlated signals like SPF/DKIM/DMARC don't double-count.
      const explanations = [
        ...headerAnalysis.anomalies,
        ...urlEvidence,
        ...domainEvidence,
        ...contentEvidence,
      ];
      // Availability context: only the caller knows whether an empty
      // category means "checked, found nothing" vs "nothing to check" —
      // see RiskComputationContext in riskEngine.ts.
      const risk = computeRisk(emailId, explanations, {
        headerDataAvailable: headerAnalysis.status !== "UNAVAILABLE",
        urlDomainApplicable: iocs.urls.length > 0 || iocs.domains.length > 0,
        infrastructureAvailable: false, // Batch 4 — GeoIP/threat-intel not implemented yet
      });

      const record: EmailRecord = {
        emailId,
        caseId,
        evidence: {
          filename: file.originalname,
          sha256: evidenceHash,
          fileSizeBytes: file.buffer.length,
          createdAt: new Date().toISOString(),
          storagePath,
        },
        parsedEmail: parsed,
        headerAnalysis,
        authentication,
        iocs,
        urlAnalysis,
        domainAnalysis,
        risk,
        aiAssessment: null,
        infrastructure: null,
        report: null,
        explanations,
        warnings,
      };

      await saveEmailRecord(record);

      const response: ScanAcceptedResponse = {
        emailId: record.emailId,
        caseId: record.caseId,
        filename: record.evidence.filename,
        sha256: record.evidence.sha256,
        fileSize: record.evidence.fileSizeBytes,
        status: "accepted",
        warnings: record.warnings,
      };

      return res.status(201).json(response);
    } catch (err) {
      return next(err);
    }
  }
);

// GET /api/v1/emails — lightweight table rows, independent of any case.
emailsRouter.get("/emails", async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const summaries = await listEmailSummaries();
    return res.status(200).json({ emails: summaries });
  } catch (err) {
    return next(err);
  }
});

// GET /api/v1/emails/:emailId — full record, fetchable directly by any
// investigation page without visiting Overview first.
emailsRouter.get(
  "/emails/:emailId",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const record = await getEmailRecord(req.params.emailId);
      if (!record) throw Errors.emailNotFound(req.params.emailId);
      return res.status(200).json(record);
    } catch (err) {
      return next(err);
    }
  }
);

// GET /api/v1/emails/:emailId/report — placeholder until Batch 6.
emailsRouter.get(
  "/emails/:emailId/report",
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const record = await getEmailRecord(req.params.emailId);
      if (!record) throw Errors.emailNotFound(req.params.emailId);
      if (!record.report) throw Errors.reportNotAvailable(req.params.emailId);
      return res.status(200).json(record.report);
    } catch (err) {
      return next(err);
    }
  }
);
