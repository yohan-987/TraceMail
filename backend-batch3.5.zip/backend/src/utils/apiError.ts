// Structured error type thrown by routes/services. The central error
// handler in server.ts converts these to the { error: { code, message } }
// shape and picks the right HTTP status — routes never build error JSON
// by hand, and no internal detail (stack traces, file paths) ever
// reaches the response body.

export class ApiError extends Error {
  code: string;
  status: number;

  constructor(code: string, message: string, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

export const Errors = {
  emailNotFound: (emailId: string) =>
    new ApiError(
      "EMAIL_NOT_FOUND",
      `The requested email could not be found: ${emailId}`,
      404
    ),
  missingFile: () =>
    new ApiError("MISSING_FILE", "Upload a .eml file under the 'file' field.", 400),
  emptyFile: () => new ApiError("EMPTY_FILE", "Uploaded file is empty.", 400),
  reportNotAvailable: (emailId: string) =>
    new ApiError(
      "REPORT_NOT_AVAILABLE",
      `No report has been generated yet for email: ${emailId}`,
      404
    ),
};
