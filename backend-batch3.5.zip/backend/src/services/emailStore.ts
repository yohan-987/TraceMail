import { promises as fs } from "fs";
import path from "path";
import type { EmailRecord, EmailSummary } from "../schemas/types";

// Layout (Batch 1 spec section 5):
//   data/emails/<emailId>/original.eml   — exact uploaded bytes, never modified
//   data/emails/<emailId>/parsed.json    — the full EmailRecord (parsed
//                                          email + every analysis slot
//                                          later batches fill in)
//
// emailId is always our own generated ID (ids.ts), never taken raw from
// user input, so directory names can't be used for path traversal —
// still sanitized defensively below.

const DATA_DIR = path.join(__dirname, "..", "..", "data", "emails");

function safeId(emailId: string): string {
  return emailId.replace(/[^A-Za-z0-9-]/g, "");
}

function emailDir(emailId: string): string {
  return path.join(DATA_DIR, safeId(emailId));
}

function originalEmlPath(emailId: string): string {
  return path.join(emailDir(emailId), "original.eml");
}

function parsedJsonPath(emailId: string): string {
  return path.join(emailDir(emailId), "parsed.json");
}

export async function saveOriginalEml(emailId: string, raw: Buffer): Promise<string> {
  const dir = emailDir(emailId);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(originalEmlPath(emailId), raw);
  // Relative path — stored in EvidenceMeta.storagePath for the record;
  // absolute paths shouldn't leak into API responses.
  return path.join("data", "emails", safeId(emailId), "original.eml");
}

export async function saveEmailRecord(record: EmailRecord): Promise<void> {
  const dir = emailDir(record.emailId);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(parsedJsonPath(record.emailId), JSON.stringify(record, null, 2), "utf-8");
}

export async function getEmailRecord(emailId: string): Promise<EmailRecord | null> {
  try {
    const raw = await fs.readFile(parsedJsonPath(emailId), "utf-8");
    return JSON.parse(raw) as EmailRecord;
  } catch (err: unknown) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw err;
  }
}

export async function listEmailSummaries(): Promise<EmailSummary[]> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const entries = await fs.readdir(DATA_DIR, { withFileTypes: true });
  const emailDirs = entries.filter((e) => e.isDirectory());

  const summaries: EmailSummary[] = [];
  for (const dirEntry of emailDirs) {
    const record = await getEmailRecord(dirEntry.name);
    if (!record) continue; // directory exists but parsed.json missing/corrupt — skip
    summaries.push({
      emailId: record.emailId,
      caseId: record.caseId,
      filename: record.evidence.filename,
      subject: record.parsedEmail?.subject ?? null,
      fromDomain: record.parsedEmail?.from?.[0]?.domain ?? null,
      createdAt: record.evidence.createdAt,
      riskScore: record.risk?.score ?? null,
      riskLevel: record.risk?.level ?? null,
    });
  }

  summaries.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return summaries;
}
